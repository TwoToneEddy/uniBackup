/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package student;

import java.awt.Color;
import java.util.Random;

/**
 *
 * @author 09092543
 */
public class KTriangle extends KShape {
    private int d;
    
    public KTriangle(int x, int y, int d, Color color) {
        super(x,y,color);
        this.d = d;
    }
    
    
    public int getD() {
        return d;
    }
   
    @Override
    public int[] getData() {
        int[] data = new int[11];
        double cosTheta = Math.cos(Math.PI / 6);
        double sinTheta = Math.sin(Math.PI / 6);

        data[0]=getColor().getRed();
        data[1]=getColor().getGreen();
        data[2]=getColor().getBlue();
        //top verticie
        data[3]=getX();
        data[4]=getY()+getD();
        
        data[5] = (int) (getX() + getD()*cosTheta);
        data[6] = (int) (getY() + getD()*sinTheta);
        data[7] = (int) (getX() - getD()*cosTheta);
        data[8] = (int) (getY() + getD()*sinTheta);

        
        return data;
    }
}
