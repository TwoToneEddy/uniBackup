/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shoppingapp;

/**
 *
 * @author user
 */
public interface PurchaseInterface {
    
    public String getName();
    public Double getUnitPrice();
    public Double getPurchasePrice();
    public String printPurchase();
    
}
