/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package assertions;

/**
 *
 * @author 09092543
 */
public class Assertions {

    //This method returns the average amount of characters in each element of the
    //String array.
    public static double what(String[] s) {  // Note: might be erroneous!
        // precondition assertions go here 
        
        for( int  j=0; j < s.length;j++){
            assert s[j] != null : "This string[] contains a null element!! "
                                + "\nMake sure the array is populated with valid strings... Lee Hudson";
        }
        
        assert s.length != 0: "This String[] contains no elements!"
                               +"\nPlease make sure the array is populated!!  Lee Hudson";
        
        double sum = 0;
        double m;
        for (int i = 0; i != s.length; i++) {
            sum += s[i].length();
        }
         m = sum / s.length;
         
         // postcondition assertions go here 
         assert m*s.length == sum : "The maths don't add up!! Lee Hudson";
         return m;
    }


    public static void main(String[] args) {
        String[] sample1 = {"David", "David", "Bedour", "Chris", "Paul"};
        String[] sample2 = {"", "", "", "", ""};
        String[] sample3 = null;
        String[] sample4 = {"David", "David", "Bedour", "Chris", "Paul"};
        sample4[3] = null;
        String[] sample5 = {};
        String[] sample6 = {"David", "David", "Bedour", "Chris", "Younas"};
        String[] sample7 = {"David", "David", "Bedour", "Chris", "Younas", 
            "Sharon", "Nigel"};


        // use this to check that assertion checking is switched on 
       // assert(false): "my test false assertion worked";  // 0

         // System.out.println(what(sample1)); // 1 
        // System.out.println(what(sample2)); // 2    -   This gives 0.0, this is correct as the String[] is empty
        // System.out.println(what(sample3)); // 3    -   This gave a null pointer exception until my assertion was applied
        // System.out.println(what(sample4)); // 4    - This gave a null pointer exception until my new assertion was applied that checked each array element
        // System.out.println(what(sample5)); // 5    - This gave an arithemtic error until my assertion was applied.
        // System.out.println(what(sample6)); // 6    -   The variable m was an int, it is now a double so it can deal with floating points.
         System.out.println(what(sample7)); // 7    - Everything appears to be fine.....
    }
}

