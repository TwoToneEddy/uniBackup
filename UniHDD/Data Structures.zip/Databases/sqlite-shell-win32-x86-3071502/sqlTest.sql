

select MCODE, avg(MARK) from REGISTER
