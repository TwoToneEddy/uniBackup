
#include <stdio.h>
int main()
{ printf("my program output this message\n");
  return 0;
}
