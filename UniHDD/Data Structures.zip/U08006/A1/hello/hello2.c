#include <stdio.h>
int main()
{ char name[80];
  printf("Your name is? \n");
  scanf("%s",name);
  printf("your name is:"+name);
  return 0;
}
