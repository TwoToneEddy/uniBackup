/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author p0073862
 */
public class BotKey implements IBotKey  {
    private Node root;
    private Node currentNode;
    public int test = 27;

    // This stack will come in handy when you implement the "undo" facility
    private Stack<Node> choiceStack = new Stack<Node>();
    
    @Override
    public boolean isLoaded() {
        return root != null;
    }
    
    @Override
    public int getNbrChildren() {
        if (currentNode == null) {
            return 0;
        } else {
            return currentNode.getNbrChildren();
        }
    }
    
    @Override
    public String getLeadStatement(int i) {
        return currentNode.getChildStatement(i);
    }
    
    @Override
    public void chooseOption(int i) {
        choiceStack.push(currentNode);
        currentNode = currentNode.getChildNode(i);
        
        
    }
    
    @Override
    public void undoChoice() {
            currentNode = choiceStack.peek();
            choiceStack.pop();
        
    }
    
    @Override
    public String getResults() {
        if(currentNode != null){
            if(currentNode.isLeaf()){
                return currentNode.getName();
            }else{
                return "There are " + currentNode.getNoOfResults() + 
                       " possibilities: \n" + currentNode.getResults();
            }
        }else{
            return "no result";
        }
    }
    
    @Override
    public void loadExample1() {
         Node southernLive = new Node("Southern live Oak: Quercus virginiana");
        Node dwarfLive = new Node("Dwarf live oak: Quercus minima");
        Node willow = new Node("Willow oak");
        Node shingle = new Node("Shingle oak");
        Node blackJack = new Node("Blackjack Oak");
        Node northernRed = new Node("Northern red oak");
        Node white = new Node("White oak Quercus alba");
        Node swampChestnut = new Node("Swamp chestnut oak Quercus prinus");


        Node node7 = new Node();
        node7.addChild(white, "Leaves with 5-9 deep lobes");
        node7.addChild(swampChestnut, "Leaves with 21-27 shallow lobes");

        Node node6 = new Node();
        node6.addChild(blackJack, "Leaves mostly with 3 lobes");
        node6.addChild(northernRed,"Leaves mostly with 7-9 lobes");

        Node node5 = new Node();
        node5.addChild(node7,
                "Lobes or teeth rounded or blunt-pointed, no bristles");
        node5.addChild(node6, "Lobes or teeth bristle-tipped");

        Node node4 = new Node();
        node4.addChild(willow, "Leaf narrow, about 4-6 times as long as broad");
        node4.addChild(shingle, "Leaf broad, about 2-3 times as long as broad");

        Node node3 = new Node();
        node3.addChild(dwarfLive,"Mature plant a small shrub");
        node3.addChild(southernLive, "Mature plant a large tree");

        Node node2 = new Node();
        node2.addChild(node4, "Leaves not evergreen");
        node2.addChild(node3, "Leaves evergreen");

        Node node1 = new Node();
        node1.addChild(node5, "Leaves usually with teeth or lobes");
        node1.addChild(node2, "Leaves usually without teeth or lobes");


        root = node1;
        currentNode = root;
}

    
    @Override
    public void loadExample2() {
        
       
        Node southernLiveOak = new Node("Southern live oak Quercus virginiana");
        Node dwarfLiveOak = new Node("Dwarf live oak Quercus minima");
        Node whiteOak = new Node("White oak Quercus alba");
        Node swampChesnutOak = new Node("Swamp chestnut oak Quercus prinus");
        Node willowOak = new Node("Willow oak Quercus phellos");
        Node shingleOak = new Node("Shingle oak Quercus imbricaria");
        Node blackjackOak = new Node("Blackjack oak Quercus marilandica");
        Node northernRedOak = new Node("Northern red oak Quercus rubra");
        
        Node node7 = new Node();
        node7.addChild( blackjackOak,"Leaves mostly with 3 lobes" );
        node7.addChild(northernRedOak, "Leaves mostly with 7-9 lobes");
        
        Node node6 = new Node();
        node6.addChild(willowOak, " Leaf narrow, about 4-6 times as long as broad");
        node6.addChild(shingleOak,"Leaf broad, about 2-3 times as long as broad");

        Node node5 = new Node();
        node5.addChild(node7,"Leaves usually with teeth or lobes");
        node5.addChild(node6, "Leaves usually without teeth or lobes");

        Node node4 = new Node();
        node4.addChild(whiteOak, "Leaves with 5-9 deep lobes");
        node4.addChild(swampChesnutOak, "Leaves with 21-27 shallow lobes ");

        Node node3 = new Node();
        node3.addChild(dwarfLiveOak,"Mature plant a small shrub");
        node3.addChild(southernLiveOak, "Mature plant a large tree");

        Node node2 = new Node();
        node2.addChild(node4, "Leaves not evergreen");
        node2.addChild(node3, "Leaves evergreen");

        Node node1 = new Node();
        node1.addChild(node5, "Styles long, acorns mature in 18 months, "
                + "very bitter, inside of acorn shell woolly"
                + " (Quercus sect. Lobatae, red oaks):");
        node1.addChild(node2, "Styles short; acorns mature in 6 months, "
                + "sweet or slightly bitter, inside of acorn shell hairless "
                + "(Quercus sect. Quercus, white oaks):");
        
        root = node1;
        currentNode = root;
                
    }
    
    @Override
    public void readFromFile(FileInputStream fs) {
        
       HashMap<Integer, Node> map = new HashMap<Integer, Node>();
      
       
       
       int keyCounter = 1;
       int parent = 0;
       int child = 0;
       StringBuffer question = new StringBuffer();
       StringBuffer leaf = new StringBuffer();
       Scanner inputFile = new Scanner(fs);
       
       
       while(inputFile.hasNext()){
           
               parent = inputFile.nextInt();
               child = inputFile.nextInt();
               
               if(child != 0){                      // if the child is not a leaf
                   if(map.containsKey(parent)){     //If we already have an entrance in the hashmap with
                                                    //this key we need to append it, not overwrite it.
                       if(!map.containsKey(child)){ // If the child hasn't been initialised we need to intialise it.
                           map.put(child, new Node());
                       }
                       map.get(parent).addChild(map.get(child), inputFile.nextLine());

                   }else{//If we don't have an entrance in the hashmap with this key we can
                         //create a new one.
                       map.put(parent, new Node()); //Create the parent Node
                       map.put(child,new Node());   //Create the child Node
                       map.get(parent).addChild(map.get(child), inputFile.nextLine());
                   }
                   
               }else{ // if the child is a leaf
                   question.delete(0, question.length()); //Clear the buffer
                   leaf.delete(0, leaf.length());
                   
                   question.append(inputFile.nextLine()); // as the first 2 ints are loaded, 
                                                           //the next will be the quesion.
                   leaf.append(inputFile.nextLine()); // As the child == 0, this is a leaf node.
                   
                   if(map.containsKey(parent)){
                       map.get(parent).addChild(new Node(leaf.substring(0)), question.substring(0));

                   }else{
                       map.put(parent, new Node());
                       map.get(parent).addChild(new Node(leaf.substring(0)), question.substring(0));
                   }   
               }
        }
       
       root = map.get(1);
       currentNode = root;
       
       
        
    }



    @Override
    public boolean canUndo() {
        if(choiceStack.empty()){
            return false;
        }else{
            return true;
        }
   }

}
