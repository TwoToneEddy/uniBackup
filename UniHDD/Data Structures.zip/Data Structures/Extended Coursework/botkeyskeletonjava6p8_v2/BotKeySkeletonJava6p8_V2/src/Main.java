/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author p0073862
 */
public class Main {
    public static void main(String[] args) {
        BotKey akey = new BotKey();
        Scanner scan = new Scanner(System.in);

        String option;
        do {
            System.out.println("Options are:");
            System.out.println("R: Read key from file");
            System.out.println("LE1: Load example 1");
            System.out.println("LE1: Load example 2");
            System.out.println("G: Get result(s)");
            System.out.println("S: Select lead");
            System.out.println("U: Undo previous selection");
            System.out.println("Q: Quit");
            option = scan.nextLine();
            option = option.toUpperCase();
            if (option.startsWith("R")) {
                readFile(akey, scan);
            }
            else if (option.startsWith("LE1")){
                akey.loadExample1();
            }
            else if (option.startsWith("LE2")){
                akey.loadExample2();
            }
            else if (option.startsWith("G")) {
                getResults(akey, scan);
            }
            else if (option.startsWith("S")) {
                selectLead(akey, scan);
            }
            else if (option.startsWith("U")) {
                undoChoice(akey);
            }
        } while (!option.startsWith("Q"));
    }

    private static void readFile(BotKey akey, Scanner scan) {
        System.out.println("Enter file name: ");
        String fileName = scan.nextLine();
        try {
            FileInputStream fs = new FileInputStream(fileName);
            akey.readFromFile(fs);
        } catch (FileNotFoundException ex) {
            System.out.println("File not found");
        }

    }

    private static void getResults(BotKey akey, Scanner scan) {
        if (checkKeyLoaded(akey)) {
            System.out.println(akey.getResults());
        }
    }
    
    private static boolean checkKeyLoaded(BotKey akey) {
        if (!akey.isLoaded()) {
            System.out.println("No key loaded yet!");
            System.out.println("Please load a key using options R,LE1, or LE2");
            return false;
        } else {
            return true;
        }

    }

    private static void selectLead(BotKey akey, Scanner scan) {
        if (checkKeyLoaded(akey)) {
            int nbrLeads = akey.getNbrChildren();
            if (nbrLeads > 0) {
                System.out.println("Pick one of the following statements:");
                for (int i = 0; i < nbrLeads; i++) {
                    System.out.println("     " + i + ":" + akey.getLeadStatement(i));
                }
                System.out.println("     " + nbrLeads + ":No suitable statements");
                System.out.println("Make your choice");
                try {
                    int choice = scan.nextInt();
                    if (choice < nbrLeads) {
                        akey.chooseOption(choice);
                    }
                } catch (InputMismatchException ex) {
                    System.out.println("That was not a number!!");
                }
            }
            if (akey.getNbrChildren() == 0) {
                System.out.println("Unique result achieved!");
                System.out.println("Plant is: " + akey.getResults());
            }
        }
    }
    

    private static void undoChoice(BotKey akey) {
        if (akey.canUndo()) {
            akey.undoChoice();
        } else {
            System.out.println("Can't undo");
        }
    }

}
