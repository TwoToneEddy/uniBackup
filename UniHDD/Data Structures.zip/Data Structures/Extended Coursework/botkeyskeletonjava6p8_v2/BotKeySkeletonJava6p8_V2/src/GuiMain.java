/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author p0073862
 */
public class GuiMain {

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(
                new Runnable() {

                    public void run() {
                        createAndShowGUI();
                    }
                });
    }

    public static void createAndShowGUI() {
        {
            IBotKey botKey = new BotKey();
            KeyModel model = new KeyModel(botKey);
            KeyView view = new KeyView(model);
            KeyController controller = new KeyController(model, view);
            view.setController(controller);
        }
    }
}
