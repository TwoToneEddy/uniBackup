/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;

/**
 *
 * @author p0073862
 */
public class Node {
    private String name;//only valid for leaves
    private ArrayList<Node> childNodes = new ArrayList<Node>();
    private ArrayList<String> statements = new ArrayList<String>();
    
    public Node() {
    }
    
    public Node(String name) {
        this.name = name;
    }
    
    public void addChild(Node node, String question) {
       childNodes.add(node);
       statements.add(question);
    }
    
    
    public Node getChildNode(int i) {
        return childNodes.get(i);
    }
    
    public String getChildStatement(int i) {
        return statements.get(i);
    }
    
    public int getNbrChildren() {
        return childNodes.size();
    }
    
    public boolean isLeaf() {
        return getNbrChildren() == 0;
    }
    
    public String getName() {
        return name;
    }
}
