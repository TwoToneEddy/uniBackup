import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

/** This class provides a little pop-up dialogue box for displaying
 *  a given image.
 *
 *  @author Sharon Curtis
 */
public class PopUp extends JDialog implements ActionListener {

    private static PopUp imageDialog;

/** Show a pop-up window with the image.
  */
    public static int showImage(BufferedImage im) {
       try {
           UIManager.setLookAndFeel(
           "com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
       }
       catch (Exception e) {
           System.out.println("Error in trying to set Windows \"look and feel\"."
                             +" Default will be used instead.");
       }

       Frame frame = JOptionPane.getFrameForComponent(null);
       imageDialog = new PopUp(frame,im,"Image Display");
       imageDialog.setVisible(true);

       return 0;
    }

/** Show a pop-up window with the image,
  * and the window has the given title.
  */
    public static int showImage(BufferedImage im, String title) {
       try {
           UIManager.setLookAndFeel(
           "com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
       }
       catch (Exception e) {
           System.out.println("Error in trying to set Windows \"look and feel\"."
                             +" Default will be used instead.");
       }

       Frame frame = JOptionPane.getFrameForComponent(null);
       imageDialog = new PopUp(frame,im,title);
       imageDialog.setVisible(true);

       return 0;
    }

   private PopUp(Frame frame, BufferedImage im, String title) {

      super(frame,title, Dialog.ModalityType.APPLICATION_MODAL );

       // display area for the image
       JLabel imageArea = new JLabel(new ImageIcon(im));
       getContentPane().add(imageArea, BorderLayout.CENTER);

       // container panel for buttons
       JPanel buttonPane = new JPanel(new FlowLayout());
       JButton cButton = new JButton("Ok");
       cButton.setActionCommand("cont");
       cButton.addActionListener(this);
       buttonPane.add(cButton);

       //JButton qButton = new JButton("Exit Program");
       //qButton.setActionCommand("quit");
       //qButton.addActionListener(this);
       //buttonPane.add(qButton);

       getContentPane().add(buttonPane, BorderLayout.SOUTH);

       setLocation(0,0);

       //Initialize values.
       pack();

    }

    public void actionPerformed(ActionEvent e) {
       if ("cont".equals(e.getActionCommand())) {
          setVisible(false);
       }
       else if ("quit".equals(e.getActionCommand())) {
          System.exit(0);
       }
    }

}
