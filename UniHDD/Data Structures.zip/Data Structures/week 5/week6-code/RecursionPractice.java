
import java.util.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.awt.event.*;


public class RecursionPractice {

    public static float power(float y, int n){
       if (n ==0)      //Base Case
            return 1;
       else           //Recursive case
           return y*power(y,n-1);
    }
    //The base case it the exit condition of the recursion, the recursive case
    //is the repitition that will decrement some variable util the base case is true.

    public static int chessBoardSquares(int n){
       if (n ==1)      //Base Case
            return 1;
       else           //Recursive case
           return chessBoardSquares(n-1)+(n+(n-1));
    }

    public static boolean arrayMatch(int n, int[] a,int[] b){

        
        if (n == 1){            //Base Case
            if (a[0]==b[0]){
                return true;
            }else{
                return false;
            }
        }else{                  //Recursive case
            if(a[n-1]==b[n-1]){
                return arrayMatch(n-1,a,b);
            }else{
                return false;
            }
        }
    }




    public static void main(String[] args) {

        int[] a = {1, 2, 3, 4, 5, 6};
        int[] b = {1, 2, 4, 8, 16};
            for (int i = 1; i <= 5; i++)
                System.out.println("arrayMatch(i, a, b) for i = " + i
                + " is " + arrayMatch(i,a,b));
        for( int i = 0; i < 30; i++)
        PopUp.showImage(recursiveImage(i));

      // leave this at the end of the method
    }

    // put your power method here








////////////////// Below is code for Exercise 6 ///////////////////

    public static BufferedImage recursiveImage(int n) {
    // [Note that the "static" keyword is used so that this method
    // can be run from the main method without requiring an instance
    // of a RecursionPractice object.]
    //
    // pre: n>=0
    // post: returns a recursively-drawn image


       if (n==0) // base case
          return blankImage(Color.black);

       else { // recursive case

          // first get a blank white image to draw on
          BufferedImage pic = blankImage(Color.white);


          // then get smaller image, ***recursively****
          BufferedImage smallPic = scale(0.4,recursiveImage(n-1));

          // now to use the small image to draw on the larger image

          // 0.5 from left, 0.25 from top (draws the upper middle section)
          drawImage(pic,smallPic,0.2,0.2);
          drawImage(pic,smallPic,0.8,0.2);

          drawImage(pic,smallPic,0.2,0.8);
          drawImage(pic,smallPic,0.8,0.8);

          drawImage(pic,smallPic,0.5,0.5);
          

          // 0.75 from left, 0.75 from top (draws the lower right section)
         // drawImage(pic,smallPic,0.75,0.75);

          return pic;
       }
    }

    public static final int imageSize = 400;

    public static BufferedImage blankImage(Color colour) {
    // creates a blank imageSize x imageSize image, of the given colour
    // (you don't need to know how the details of this method work,
    // only what the method does)

       BufferedImage im = new BufferedImage(imageSize,imageSize,
                                            BufferedImage.TYPE_INT_RGB);
	   Graphics2D g2d = im.createGraphics(); // get graphics context
	   g2d.setPaint(colour);
	   g2d.fill(new Rectangle2D.Double(0.0,0.0,1.0*imageSize,1.0*imageSize));
       return im;
    }

    public static BufferedImage scale(double scalingFactor,
                                      BufferedImage inputImage) {
    // pre:  scalingFactor > 0
    // post: returns an image that is a scaled version of the inputImage
    // (you don't need to know how the details of this method work,
    // only what the method does)

       int w = (int)(scalingFactor*inputImage.getWidth());
       int h = (int)(scalingFactor*inputImage.getHeight());
       BufferedImage im
             = new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);
	   Graphics2D g = im.createGraphics(); // get graphics context
       g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, // anti-aliasing
	                      RenderingHints.VALUE_ANTIALIAS_ON);
       AffineTransform at = new AffineTransform();
       at.scale(scalingFactor,scalingFactor);
       g.setTransform(at); // sets the drawing to a scaling transform
       g.drawImage(inputImage,null,0,0);

       return im;

    }

    public static void drawImage(BufferedImage background,
                                 BufferedImage drawPic,
                                 double leftOffset,
                                 double topOffset) {
    // draws the drawPic image onto the background image
    // (you don't need to know how the details of this method work,
    // only what the method does)

       int w = background.getWidth();
       int h = background.getHeight();
	   Graphics2D g = background.createGraphics(); // get graphics context
       g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, // anti-aliasing
	                      RenderingHints.VALUE_ANTIALIAS_ON);
       int x = (int)(leftOffset*w - (drawPic.getWidth()/2.0));
       int yTop = (int)(topOffset*h - (drawPic.getHeight()/2.0));
       g.drawImage(drawPic,null,x,yTop);

    }


}

