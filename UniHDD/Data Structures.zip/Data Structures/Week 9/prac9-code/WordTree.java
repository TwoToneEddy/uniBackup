// U08223 Practical 10.
// Bodies of methods:
//   recordWord,
//   display and
//   numberOfEntries
// to be completed by student


import java.util.*;

/** A class representing a binary tree containing words.
 *
 * @author student's name goes here
 */
public class WordTree {

    public String word;
    public ArrayList<Integer> lineNumbers;
    public WordTree left, right;

    /** Constructs a tree consisting of a single node, with
     * the given word and line number.
     *
     * @param w           the word
     * @param lineNo      the line number
     * @pre               true
     * @post              word tree containing word w on line lineNo has been constructed
     */
    public WordTree(String w, int lineNo) {
        word = w;
        lineNumbers = new ArrayList<Integer>();
        lineNumbers.add(lineNo);
        left = null;
        right = null;
    }

    /** Records a new occurrence of the given word, in the tree.
     *
     * @param w           the word
     * @param lineNo      the line number
     * @pre               this is a well formed binary search tree
     * @post              if word was not in this tree, then the word and its line number
     *                    line have been inserted into ordered word tree,
     *                    else line has been appended to line-number list for word
     *                    (if we haven't already recorded that line number for this word)
     */
    public void recordWord(String w, int lineNo) {
        //student to supply body of this method
        if(w.compareToIgnoreCase(word) == 0){ //this word already exists
            if(lineNumbers.contains(lineNo)){ //if its already occured on this line do nothing

            }else{
                lineNumbers.add(lineNo);        //If it hasnt occured on this line add the line number
            }
        }else{                                  //If the word doesn't exist

            if(w.compareToIgnoreCase(word) < 0){    //If the word is less than the current word and the
                if(left == null){                   // left subtree is null then add it.
                    left = new WordTree(w,lineNo);
                }else{
                    left.recordWord(w, lineNo);
                }
            }else{
                if(right == null){
                    right = new WordTree(w,lineNo);
                }else{
                    right.recordWord(w, lineNo);
                }
            }
        }
    }

    /** Displays all the words in this tree.
     *
     * @pre               this is a well formed binary search tree
     * @post              words have been written out in alphabetical order,
     *                    each followed by ascending list of line numbers
     *                    on which the word occurs
     */
    public void display() {
        //student to supply body of this method
        String lineNumber = "";
        if(left != null){
            left.display();
        }
        for(int i = 0; i < lineNumbers.size(); i++){
            lineNumber = lineNumber +" " + Integer.toString(lineNumbers.get(i)) +",";
        }
        System.out.println(word + lineNumber);
        if(right != null){
            right.display();
        }

    }

    /** Counts how many different words there are in this tree.
     *
     * @pre       this is a well formed binary search tree
     * @return    the number of different words in tree
     */
    public int numberOfEntries() {
        //student to supply body of this method
        int entries = 1;
        if( left != null){
            entries = entries + left.numberOfEntries();
        }

        if(right != null){
            entries = entries + right.numberOfEntries();
        }
        
        return entries; // dummy value returned, to keep compiler happy!
    }
}



/*************************************
Producing a cross-reference for the file:
Moses.txt
************************************

1: Moses supposes his toeses are Roses,
2: But Moses supposes erroneously,
3: Moses he knowses his toeses aren't roses,
4: As Moses supposes his toeses to be!
5: Moses supposes his toeses are Roses,
6: But Moses supposes erroneously,
7: A mose is a mose!
8: A rose is a rose!
9: A toes a toes!
10: Hooptie doodie doodle
11: Moses supposes his toeses are Roses,
12: But Moses supposes erroneously,
13: For Moses he knowses his toeses aren't roses,
14: As Moses supposes his toeses to be!
15: Moses
16: (Moses supposes his toeses are roses)
17: Moses
18: (Moses supposes erroneously)
19: Moses
20: (Moses supposes his toeses are roses)
21: As Moses supposes his toeses to be!
22: A Rose is a rose is a rose is a rose is
23: A rose is for Moses as potent as toeses
24: Couldn't be a lily or a daphi daphi dilli
25: It's gotta be a rose cuz it rhymes with mose!
26: Moses!
27: Moses!
28: Moses!


A 7, 8, 9, 22, 23, 24, 25,
are 1, 5, 11, 16, 20,
aren't 3, 13,
As 4, 14, 21, 23,
be 4, 14, 21, 24, 25,
But 2, 6, 12,
Couldn't 24,
cuz 25,
daphi 24,
dilli 24,
doodie 10,
doodle 10,
erroneously 2, 6, 12, 18,
For 13, 23,
gotta 25,
he 3, 13,
his 1, 3, 4, 5, 11, 13, 14, 16, 20, 21,
Hooptie 10,
is 7, 8, 22, 23,
it 25,
It's 25,
knowses 3, 13,
lily 24,
mose 7, 25,
Moses 1, 2, 3, 4, 5, 6, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 23, 26, 27, 28,
or 24,
potent 23,
rhymes 25,
rose 8, 22, 23, 25,
Roses 1, 3, 5, 11, 13, 16, 20,
supposes 1, 2, 4, 5, 6, 11, 12, 14, 16, 18, 20, 21,
to 4, 14, 21,
toes 9,
toeses 1, 3, 4, 5, 11, 13, 14, 16, 20, 21, 23,
with 25,

number of words: 144
number of different words: 35
 */
