/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.*;
/**
 *
 * @author 09092543
 */
public class WordStore {

    HashMap<String,Integer> mapInstance;
    HashSet<String> commonWords;

    WordStore(){
        mapInstance = new HashMap<String,Integer>();
        commonWords = new HashSet<String>();
    }
/*@param String value to be added to mapInstance if
 *
 */
    void addWord(String value){
        if(!commonWords.contains(value)){
            int keyVal = 0;
            if(mapInstance.containsKey(value)){
                keyVal = mapInstance.get(value);
                keyVal ++;
                mapInstance.remove(value);
                mapInstance.put(value, keyVal);
            }
            else{
                mapInstance.put(value, 1);
            }
        }
    }

/*
 *
 */
   ArrayList<WordCount> getCounts(){
        ArrayList<WordCount> temp = new ArrayList<WordCount>();

        for (String S : mapInstance.keySet()){
            temp.add(new WordCount(S, mapInstance.get(S)));
        }
        return temp;
    }
/*
 *
 */
   void addCommonWord(String S){
       commonWords.add(S);
   }
}