

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.awt.font.*;
import java.util.*;

/** Provides facilities for making tag clouds.
  *
  * @author Sharon Curtis
  */
public class CloudMaker extends JDialog implements ActionListener {

    private static CloudMaker imageDialog;
    private static final int minFontSize = 6;
    private static final int maxFontSize = 20;
    private static final String fontFace = "Verdana";


/** Creates and displays a tag cloud image, from the given tags.
  * Only tags sufficiently common are included.
  *
  * @param  tagCounts   the list of tags, together with their frequencies
  * @param  level       the number of occurrences a tag must have, to be
  *                     included in the cloud
  * @return             returns zero if this method is successfully completed
  */
    public static int showCloud(ArrayList<WordCount> tagCounts, int level) {

        preProcess(tagCounts,level);
        Collections.sort(tagCounts);
        ColourScheme c = getRandomColourScheme();
        BufferedImage im = getCloudImage(tagCounts,c);

        // GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        // Font[] fonts = ge.getAllFonts();
        // for (int i=0; i<fonts.length; i++) {
        //     System.out.println(fonts[i].getFontName()+" "+fonts[i].getSize());
        // }

        try {
            UIManager.setLookAndFeel(
            "com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        }
        catch (Exception e) {
            System.out.println("Error in trying to set Windows \"look and feel\"."
                            +" Default will be used instead.");
        }
        Frame frame = JOptionPane.getFrameForComponent(null);
        imageDialog = new CloudMaker(frame,im,"Tag Cloud",c.background);
        imageDialog.setVisible(true);

        // afterwards
        return 0;
    }

    private static void preProcess(ArrayList<WordCount> tagCounts, int level) {

        int i = 0;
        while (i<tagCounts.size()) {
            if (tagCounts.get(i).count<level)
                tagCounts.remove(i);
            else {
                String w = tagCounts.get(i).word;
                tagCounts.get(i).word = " " + w + " ";
                i++;
            }
        }
        Collections.sort(tagCounts);

    }

    private CloudMaker(Frame frame, BufferedImage im, String title, Color bg) {

        super(frame,title, Dialog.ModalityType.APPLICATION_MODAL );

        // display area for the image
        JLabel imageArea = new JLabel(new ImageIcon(im));
        imageArea.setBackground(bg);

        getContentPane().add(imageArea, BorderLayout.CENTER);
        getContentPane().setBackground(bg);

        //Initialize values.
        pack();


    }

    public void actionPerformed(ActionEvent e) {
        if ("quit".equals(e.getActionCommand())) {
           setVisible(false);
        }
    }



    private static double wordBorder = 2.0;

    private static BufferedImage getCloudImage(ArrayList<WordCount> tagCounts,
                                               ColourScheme c) {
    // Returns a BufferedImage displaying this tag cloud.

        // First get some fonts, and thus rectangle sizes, for all the tags
        ArrayList<TagDisplay> tds = getRectangles(tagCounts);
        // At this point, the rectangle coordinates are as usual
        // given by (x,y) top-left corner, plus width and height,
        // however the coordinate are with respect to x right, y up axes,
        // and centred on the origin (0,0)

        // Then we need to figure out how big to make the image
        double minX = 0.0;
        double maxX = 0.0;
        double minY = 0.0;
        double maxY = 0.0;
        for (TagDisplay td : tds) {
            if (td.rect.getX()<minX)
                minX = td.rect.getX();
            if (td.rect.getX()+td.rect.getWidth()>maxX)
                maxX = td.rect.getX()+td.rect.getWidth();
            if (td.rect.getY()<minY)
                minY = td.rect.getY();
            if (td.rect.getY()+td.rect.getHeight()>maxY)
                maxY = td.rect.getY()+td.rect.getHeight();
        }
        // System.out.println("maxX is "+maxX);
        // System.out.println("minX is "+minX);
        // System.out.println("maxY is "+maxY);
        // System.out.println("minY is "+minY);

        int imageWidth = (int)(maxX-minX) + 80;
        int imageHeight = (int)(maxY-minY) + 80;
        double scale = 2.0;

        // now we can adjust the rectangles to get them centred,
        // and put into Java-oriented coordinates
        for (TagDisplay td : tds) {
             Rectangle2D.Double shifted
                = new Rectangle2D.Double(imageWidth/2.0+td.rect.getX(),
                                         imageHeight/2.0-td.rect.getY(),
                                         td.rect.getWidth(),
                                         td.rect.getHeight());
             td.rect = shifted;
        }

        // then create the image
        BufferedImage bimage = new BufferedImage((int)scale*imageWidth,
                                                 (int)scale*imageHeight,
                                                 BufferedImage.TYPE_INT_RGB);

        // set up the graphics context for the image
        Graphics2D g = bimage.createGraphics();
        g.setPaint(c.background);
        g.fill(new Rectangle2D.Double(0.0,0.0,scale*imageWidth,scale*imageHeight));
        g.setStroke(new BasicStroke (1, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);
        g.scale(scale,scale);

        // finally we draw the tag cloud
        g.setPaint(c.foreground);
        for (TagDisplay td : tds) {
            // g.draw(td.rect);
            Font f = new Font(fontFace, Font.BOLD, td.fontSize);
            g.setFont(f);
            GlyphVector gl = f.createGlyphVector(g.getFontRenderContext(),td.wc.word);
            Shape shape = gl.getGlyphLogicalBounds(0); // where's the first letter of the word?
            Rectangle2D bounds = shape.getBounds2D();
            float offset = (float)(bounds.getY()+bounds.getHeight());
            //AffineTransform slide = new AffineTransform();
            //slide.translate(td.rect.getX(),td.rect.getY()+td.rect.getHeight());
            //g.draw(slide.createTransformedShape(shape));
            g.drawString(td.wc.word,
                         (float)(td.rect.getX()+wordBorder),
                         (float)(td.rect.getY()+td.rect.getHeight()-offset-wordBorder));
        }
        return bimage;
    }

    private static ArrayList<TagDisplay> getRectangles(ArrayList<WordCount> tagCounts) {

        // first, figure out all the font sizes for the words
        ArrayList<TagDisplay> tds = setFontSizes(tagCounts);

        // next, grab a graphics context in order to figure out
        // the box sizes for the words when rendered
        BufferedImage bimage = new BufferedImage(100,100,BufferedImage.TYPE_INT_RGB);
        Graphics2D g = bimage.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                           RenderingHints.VALUE_ANTIALIAS_ON);

        for (int t=0; t<tds.size(); t++) {
            TagDisplay td = tds.get(t);
            Font f = new Font(fontFace, Font.BOLD, td.fontSize);
            g.setFont(f);
            GlyphVector gl = f.createGlyphVector(g.getFontRenderContext(),td.wc.word);
            Rectangle2D box = gl.getVisualBounds();

            if (t==0) {
                // bang in the centre for the first rectangle
                td.rect = new Rectangle2D.Double(0.0-box.getWidth()/2.0-wordBorder, // top-left
                                                 0.0+box.getHeight()/2.0+wordBorder, // corner
                                                 (double)box.getWidth()+2*wordBorder,
                                                 (double)box.getHeight()+2*wordBorder);
            // System.out.println("box ("+t+"), width is " + box.getWidth()
            //                    + " and height is "+ box.getHeight());
            // System.out.println("td ("+t+") top-left corner is ("+td.rect.getX()+","
            //                    +td.rect.getY()+"), width is " + td.rect.getWidth()
            //                    + " and height is "+ td.rect.getHeight());
            }
            else {
                Rectangle2D.Double boxb = new Rectangle2D.Double(0.0,0.0,
                                                                 box.getWidth()+2*wordBorder,
                                                                 box.getHeight()+2*wordBorder);
                ArrayList<Point2D.Double> possibilities = getPossibleLocations(tds,t,boxb);
                int choice = 0;
                double scaleX = 3.0;
                double scaleY = 5.0;
                double dist = possibilities.get(0).getX()*possibilities.get(0).getX()*scaleX*scaleX
                              + possibilities.get(0).getY()*possibilities.get(0).getY()*scaleY*scaleY;
                for (int i=1; i<possibilities.size(); i++) {
                    double nextDist = possibilities.get(i).getX()*possibilities.get(i).getX()*scaleX*scaleX
                                      + possibilities.get(i).getY()*possibilities.get(i).getY()*scaleY*scaleY;
                    if (nextDist<dist) {
                        choice = i;
                        dist = nextDist;
                    }
                }
            // System.out.println("boxb ("+t+"), width is " + boxb.getWidth()
            //                    + " and height is "+ boxb.getHeight());
                Point2D.Double pos = possibilities.get(choice);
                td.rect = new Rectangle2D.Double(pos.getX()-boxb.getWidth()/2.0, // top-left
                                                 pos.getY()+boxb.getHeight()/2.0, // corner
                                                 (double)boxb.getWidth(),
                                                 (double)boxb.getHeight());
            // System.out.println("td ("+t+") top-left corner is ("+td.rect.getX()+","
            //                    +td.rect.getY()+"), width is " + td.rect.getWidth()
            //                    + " and height is "+ td.rect.getHeight());

            }
        }
        return tds;
    }

    private static ArrayList<TagDisplay> setFontSizes(ArrayList<WordCount> tagCounts) {
    // pre: tagCounts.size()>0
    //      (all counts should be at least 1, but can't rely on that)

        int maxFreq = tagCounts.get(0).count;
        int minFreq = tagCounts.get(tagCounts.size()-1).count;
        if (minFreq<1)
            minFreq = 1;


        ArrayList<TagDisplay> tds = new ArrayList<TagDisplay>();
        for (WordCount wc: tagCounts) {
            TagDisplay td = new TagDisplay(wc);
            if (wc.count<1)
                td.fontSize = minFontSize;
            else {
                double d = (Math.sqrt((double)wc.count) - Math.sqrt((double)minFreq))
                           /(Math.sqrt((double)maxFreq) - Math.sqrt((double)minFreq));
                td.fontSize = minFontSize + (int)(d*(maxFontSize-minFontSize));
                // System.out.println("Assigned font size of "+td.fontSize+" to word \""
                //                    + td.wc.word + "\", of frequency " + td.wc.count);
            }
            tds.add(td);
        }
        return tds;
    }

    private static ArrayList<Point2D.Double> getPossibleLocations(ArrayList<TagDisplay> tds,
                                                                  int tag,
                                                                  Rectangle2D box) {
        // finds possible locations for the centre of the box

        ArrayList<Point2D.Double> pos = new ArrayList<Point2D.Double>();
        addVerticalDrops(pos,tds,tag,box);
        addUpDrops(pos,tds,tag,box);
        addLeftDrops(pos,tds,tag,box);
        addRightDrops(pos,tds,tag,box);
        return pos;
    }

    private static void addVerticalDrops(ArrayList<Point2D.Double> pos,
                                         ArrayList<TagDisplay> tds,
                                         int tag, Rectangle2D box) {
    // pos: list of possible positions, to add candidate positions to
    // tds: list of all the rectangles
    // t:   how many rectangles we've positioned so far, i.e. only the
    //      first t elements of tds have rectangle coordinates, the rest
    //      just have font size information
    // box: the size of the rectangle we're trying to position
    //      (we just use the width and height,   (x,y are just 0,0)

        // top of the cloud first
        double maxY = 0.0;
        for (int t=0; t<tag; t++) {
            TagDisplay td = tds.get(t);
//            System.out.println("td top-left corner is ("+td.rect.getX()+","
//                               +td.rect.getY()+"), width is " + td.rect.getWidth()
//                               + " and height is "+ td.rect.getHeight());
            // td.rect is specified by top-left corner, width, height
            if (td.rect.getY()>maxY)
               maxY = td.rect.getY();
        }
        // System.out.println("maxY is"+maxY);
        // System.out.println("adding location 0.0,"+(maxY+box.getHeight()/2.0));
        pos.add(new Point2D.Double(0.0,maxY+box.getHeight()/2.0));

        // imagine the box dropping in turn on each of the existing
        // rectangles, on the right-hand end, and then we check with all
        // the other rectangles to see whether that's a feasible position or not
        for (int t=0; t<tag; t++) {
            TagDisplay td = tds.get(t);
            Point2D.Double p =  // on top of td, on rhs
                new Point2D.Double(td.rect.getX()+td.rect.getWidth()-box.getWidth()/2.0,
                                   td.rect.getY()+box.getHeight()/2.0);
            for (int u=0; u<tag; u++) {
                if (u!=t) {
                   TagDisplay ud = tds.get(u);
                   // if rectangle u overlaps the horizontal band/shadow of
                   // the box in position p, then shift box leftwards if necessary
                   if (inHorizontalBoxBand(p,box,ud)) {
                       // if rhs of box at p is right of lhs of u
                       if ((p.x+box.getWidth()/2.0)>ud.rect.getX())
                           // shift left to make rhs of box p at lhs of u
                           p.x = ud.rect.getX()-box.getWidth()/2.0;
                   }
                }
            }
            // now the box got shifted leftwards of everything that overlapped the band,
            // or is still sat on the left-hand end of p, because nothing overlapped
            pos.add(p);
            // System.out.println("adding rhs location p=("+p.x+","+p.y+")");
        }


        // Similar to above, imagine the box dropping in turn on each of the existing
        // rectangles, on the left-hand end, and then we check with all
        // the other rectangles to see whether that's a feasible position or not
        for (int t=0; t<tag; t++) {
            TagDisplay td = tds.get(t);
            Point2D.Double p =    // on top of td, on lhs
                new Point2D.Double(td.rect.getX()+box.getWidth()/2.0,
                                   td.rect.getY()+box.getHeight()/2.0);
            for (int u=0; u<tag; u++) {
                if (u!=t) {
                   TagDisplay ud = tds.get(u);
                   // if rectangle u overlaps the horizontal band/shadow of
                   // the box in position p, then shift box rightwards if necessary
                   if (inHorizontalBoxBand(p,box,ud)) {
                       // if lhs of box at p is left of rhs of u
                       if ((p.x-box.getWidth()/2.0)<ud.rect.getX()+ud.rect.getWidth())
                           // shift right to make lhs of box p at rhs of u
                           p.x = ud.rect.getX()+ud.rect.getWidth()+box.getWidth()/2.0;
                   }
                }
            }
            // now the box got shifted leftwards of everything that overlapped the band,
            // or is still sat on the left-hand end of p, because nothing overlapped
            pos.add(p);
            // System.out.println("adding lhs location p=("+p.x+","+p.y+")");
        }

    } // end of addVerticalDrops

    private static void addUpDrops(ArrayList<Point2D.Double> pos,
                                         ArrayList<TagDisplay> tds,
                                         int tag,
                                         Rectangle2D box) {
        // bottom of the cloud first
        double minY = 0.0;
        for (int t=0; t<tag; t++) {
            TagDisplay td = tds.get(t);
            // td.rect is specified by top-left corner, width, height
            if (td.rect.getY()-td.rect.getHeight()<minY)
               minY = td.rect.getY()-td.rect.getHeight();
        }
        pos.add(new Point2D.Double(0.0,minY-box.getHeight()/2.0));

        // then left and right

        // imagine the box floating in turn up to each of the existing
        // rectangles, on the right-hand end, and then we check with all
        // the other rectangles to see whether that's a feasible position or not
        for (int t=0; t<tag; t++) {
            TagDisplay td = tds.get(t);
            Point2D.Double p =  // on top of td, on rhs
                new Point2D.Double(td.rect.getX()+td.rect.getWidth()-box.getWidth()/2.0,
                                   td.rect.getY()-td.rect.getHeight()-box.getHeight()/2.0);
            for (int u=0; u<tag; u++) {
                if (u!=t) {
                   TagDisplay ud = tds.get(u);
                   // if rectangle u overlaps the horizontal band/shadow of
                   // the box in position p, then shift box leftwards if necessary
                   if (inHorizontalBoxBand(p,box,ud)) {
                       // if rhs of box at p is right of lhs of u
                       if ((p.x+box.getWidth()/2.0)>ud.rect.getX())
                           // shift left to make rhs of box p at lhs of u
                           p.x = ud.rect.getX()-box.getWidth()/2.0;
                   }
                }
            }
            // now the box got shifted leftwards of everything that overlapped the band,
            // or is still sat on the left-hand end of p, because nothing overlapped
            pos.add(p);
            // System.out.println("up: adding rhs location p=("+p.x+","+p.y+")");
        }


        // Similar to above, imagine the box floating up to each of the existing
        // rectangles, on the left-hand end, and then we check with all
        // the other rectangles to see whether that's a feasible position or not
        for (int t=0; t<tag; t++) {
            TagDisplay td = tds.get(t);
            Point2D.Double p =    // on top of td, on lhs
                new Point2D.Double(td.rect.getX()+box.getWidth()/2.0,
                                   td.rect.getY()-td.rect.getHeight()-box.getHeight()/2.0);
            for (int u=0; u<tag; u++) {
                if (u!=t) {
                   TagDisplay ud = tds.get(u);
                   // if rectangle u overlaps the horizontal band/shadow of
                   // the box in position p, then shift box rightwards if necessary
                   if (inHorizontalBoxBand(p,box,ud)) {
                       // if lhs of box at p is left of rhs of u
                       if ((p.x-box.getWidth()/2.0)<ud.rect.getX()+ud.rect.getWidth())
                           // shift right to make lhs of box p at rhs of u
                           p.x = ud.rect.getX()+ud.rect.getWidth()+box.getWidth()/2.0;
                   }
                }
            }
            // now the box got shifted leftwards of everything that overlapped the band,
            // or is still sat on the left-hand end of p, because nothing overlapped
            pos.add(p);
            // System.out.println("up: adding lhs location p=("+p.x+","+p.y+")");
        }


    } // end of addUpDrops

    private static boolean inHorizontalBoxBand(Point2D.Double p,
                                               Rectangle2D box,
                                               TagDisplay d) {

        // consider box centered on p, does d overlap its
        // horizontal range?

        boolean outOfRange =
                 (d.rect.getY()-d.rect.getHeight() // lower edge of d rectangle
                   > p.y+box.getHeight()/2.0 )       // further up than top edge of box
                 ||
                 (d.rect.getY()                    // top edge of d rectangle
                   < p.y-box.getHeight()/2.0 );       // lower down than bottom of box

        return !outOfRange;
    }

    private static void addLeftDrops(ArrayList<Point2D.Double> pos,
                                         ArrayList<TagDisplay> tds,
                                         int tag,
                                         Rectangle2D box) {
        // left of the cloud first
        double minX = 0.0;
        for (int t=0; t<tag; t++) {
            TagDisplay td = tds.get(t);
            // td.rect is specified by top-left corner, width, height
            if (td.rect.getX()<minX)
               minX = td.rect.getX();
        }
        pos.add(new Point2D.Double(minX-box.getWidth()/2.0,0.0));


        // imagine the box floating in from the left, onto each of the existing
        // rectangles, top-aligned, and then we check with all the other
        // rectangles to see whether that's a feasible position or not
        for (int t=0; t<tag; t++) {
            TagDisplay td = tds.get(t);
            Point2D.Double p =  // on lhs of td, top-aligned
                new Point2D.Double(td.rect.getX()-box.getWidth()/2.0,
                                   td.rect.getY()-box.getHeight()/2.0);
            for (int u=0; u<tag; u++) {
                if (u!=t) {
                   TagDisplay ud = tds.get(u);
                   // if rectangle u overlaps the vertical band/shadow of
                   // the box in position p, then shift box downwards if necessary
                   if (inVerticalBoxBand(p,box,ud)) {
                       // if top edge of box at p is upwards of bottom edge of u
                       if ((p.y+box.getHeight()/2.0)>(ud.rect.getY()-ud.rect.getHeight()))
                           // shift down to make top of box p at bottom of u
                           p.y = ud.rect.getY()-ud.rect.getHeight()-box.getHeight()/2.0;
                   }
                }
            }
            // now the box got shifted downwards of everything that overlapped the band,
            // or is still aligned with the top edge of p, because nothing overlapped
            pos.add(p);
            // System.out.println("l: adding rhs location p=("+p.x+","+p.y+")");
        }


        // Similar to above, imagine the box floating in from the left, onto each of
        // the existing rectangles, bottom-aligned, and then we check with all the other
        // rectangles to see whether that's a feasible position or not

        for (int t=0; t<tag; t++) {
            TagDisplay td = tds.get(t);
            Point2D.Double p =  // on lhs of td, bottom-aligned
                new Point2D.Double(td.rect.getX()-box.getWidth()/2.0,
                                   td.rect.getY()-td.rect.getHeight()+box.getHeight()/2.0);
            for (int u=0; u<tag; u++) {
                if (u!=t) {
                   TagDisplay ud = tds.get(u);
                   // if rectangle u overlaps the horizontal band/shadow of
                   // the box in position p, then shift box rightwards if necessary
                   if (inVerticalBoxBand(p,box,ud)) {
                       // if bottom edge of box at p is downwards of top edge of u
                       if ((p.y-box.getHeight()/2.0)<(ud.rect.getY()))
                           // shift up to make bottom of p at top of u
                           p.y = ud.rect.getY()+box.getHeight()/2.0;
                   }
                }
            }
            // now the box got shifted leftwards of everything that overlapped the band,
            // or is still sat on the left-hand end of p, because nothing overlapped
            pos.add(p);
            // System.out.println("l: adding lhs location p=("+p.x+","+p.y+")");
        }

    } // end of addLeftDrops


    private static void addRightDrops(ArrayList<Point2D.Double> pos,
                                         ArrayList<TagDisplay> tds,
                                         int tag,
                                         Rectangle2D box) {
        // right of the cloud first
        double maxX = 0.0;
        for (int t=0; t<tag; t++) {
            TagDisplay td = tds.get(t);
            // td.rect is specified by top-left corner, width, height
            if (td.rect.getX()+td.rect.getWidth()>maxX)
               maxX = td.rect.getX()+td.rect.getWidth();
        }
        pos.add(new Point2D.Double(maxX+box.getWidth()/2.0,0.0));

        // imagine the box floating in from the right, onto each of the existing
        // rectangles, top-aligned, and then we check with all the other
        // rectangles to see whether that's a feasible position or not
        for (int t=0; t<tag; t++) {
            TagDisplay td = tds.get(t);
            Point2D.Double p =  // on rhs of td, top-aligned
                new Point2D.Double(td.rect.getX()+td.rect.getWidth()+box.getWidth()/2.0,
                                   td.rect.getY()-box.getHeight()/2.0);
            for (int u=0; u<tag; u++) {
                if (u!=t) {
                   TagDisplay ud = tds.get(u);
                   // if rectangle u overlaps the vertical band/shadow of
                   // the box in position p, then shift box downwards if necessary
                   if (inVerticalBoxBand(p,box,ud)) {
                       // if top edge of box at p is upwards of bottom edge of u
                       if ((p.y+box.getHeight()/2.0)>(ud.rect.getY()-ud.rect.getHeight()))
                           // shift down to make top of box p at bottom of u
                           p.y = ud.rect.getY()-ud.rect.getHeight()-box.getHeight()/2.0;
                   }
                }
            }
            // now the box got shifted downwards of everything that overlapped the band,
            // or is still aligned with the top edge of p, because nothing overlapped
            pos.add(p);
            // System.out.println("r: adding rhs location p=("+p.x+","+p.y+")");
        }


        // Similar to above, imagine the box floating in from the right, onto each of
        // the existing rectangles, bottom-aligned, and then we check with all the other
        // rectangles to see whether that's a feasible position or not

        for (int t=0; t<tag; t++) {
            TagDisplay td = tds.get(t);
            Point2D.Double p =  // on rhs of td, bottom-aligned
                new Point2D.Double(td.rect.getX()+td.rect.getWidth()+box.getWidth()/2.0,
                                   td.rect.getY()-td.rect.getHeight()+box.getHeight()/2.0);
            for (int u=0; u<tag; u++) {
                if (u!=t) {
                   TagDisplay ud = tds.get(u);
                   // if rectangle u overlaps the horizontal band/shadow of
                   // the box in position p, then shift box rightwards if necessary
                   if (inVerticalBoxBand(p,box,ud)) {
                       // if bottom edge of box at p is downwards of top edge of u
                       if ((p.y-box.getHeight()/2.0)<(ud.rect.getY()))
                           // shift up to make bottom of p at top of u
                           p.y = ud.rect.getY()+box.getHeight()/2.0;
                   }
                }
            }
            // now the box got shifted leftwards of everything that overlapped the band,
            // or is still sat on the left-hand end of p, because nothing overlapped
            pos.add(p);
            // System.out.println("r: adding lhs location p=("+p.x+","+p.y+")");
        }

    } // end of addRightDrops

    private static boolean inVerticalBoxBand(Point2D.Double p,
                                               Rectangle2D box,
                                               TagDisplay d) {

        // consider box centered on p, does d overlap its
        // vertical range?

        boolean outOfRange =
                 (d.rect.getX()                     // left edge of d rectangle
                   > p.x+box.getWidth()/2.0 )       // further right than rhs of box
                 ||
                 (d.rect.getX()+d.rect.getWidth()   // right edge of d rectangle
                   < p.x-box.getWidth()/2.0 );      // further left than lhs of box

        return !outOfRange;
    }



    private static ArrayList<ColourScheme> setUpColourSchemes() {
    // sets up various assorted colour schemes, with
    // appropriately-contrasting foreground/background colour pairs
        ArrayList<ColourScheme> schemes = new ArrayList<ColourScheme>();
        schemes.add(new ColourScheme(new Color(0,0,93),new Color(244,169,169)));
        schemes.add(new ColourScheme(new Color(0,0,93),new Color(174,181,244)));
        schemes.add(new ColourScheme(new Color(0,0,93),new Color(107,244,109)));
        schemes.add(new ColourScheme(new Color(0,0,93),new Color(244,201,140)));
        schemes.add(new ColourScheme(new Color(0,0,93),new Color(244,234,140)));
        schemes.add(new ColourScheme(new Color(5,72,28),new Color(206,206,206)));
        schemes.add(new ColourScheme(new Color(5,72,28),new Color(183,188,240)));
        schemes.add(new ColourScheme(new Color(5,72,28),new Color(220,190,240)));
        schemes.add(new ColourScheme(new Color(5,72,28),new Color(205,239,209)));
        schemes.add(new ColourScheme(new Color(255,255,255),new Color(8,184,161)));
        schemes.add(new ColourScheme(new Color(255,255,255),new Color(110,184,8)));
        schemes.add(new ColourScheme(new Color(255,255,255),new Color(8,108,184)));
        schemes.add(new ColourScheme(new Color(255,255,255),new Color(147,8,184)));
        schemes.add(new ColourScheme(new Color(255,255,255),new Color(184,8,100)));
        schemes.add(new ColourScheme(new Color(255,255,255),new Color(184,8,8)));
        schemes.add(new ColourScheme(new Color(255,255,255),new Color(228,101,10)));
        schemes.add(new ColourScheme(new Color(255,255,255),new Color(0,167,99)));
        schemes.add(new ColourScheme(new Color(72,72,72),new Color(154,174,194)));
        schemes.add(new ColourScheme(new Color(72,72,72),new Color(166,194,154)));
        schemes.add(new ColourScheme(new Color(72,72,72),new Color(228,149,149)));
        schemes.add(new ColourScheme(new Color(90,25,105),new Color(228,149,189)));
        schemes.add(new ColourScheme(new Color(90,25,105),new Color(149,205,228)));
        schemes.add(new ColourScheme(new Color(90,25,105),new Color(200,187,243)));
        schemes.add(new ColourScheme(new Color(164,39,39),new Color(200,243,187)));
        schemes.add(new ColourScheme(new Color(164,39,39),new Color(196,212,191)));
        schemes.add(new ColourScheme(new Color(164,39,39),new Color(255,205,183)));
        schemes.add(new ColourScheme(new Color(106,59,14),new Color(255,230,183)));
        schemes.add(new ColourScheme(new Color(106,59,14),new Color(220,255,183)));
        schemes.add(new ColourScheme(new Color(106,59,14),new Color(183,255,254)));
        schemes.add(new ColourScheme(new Color(106,59,14),new Color(206,209,255)));
        return schemes;
    }

    private static ColourScheme getRandomColourScheme() {
        ArrayList<ColourScheme> colourSchemes = setUpColourSchemes();
        Random rng = new Random(); // random number generator
        int i = rng.nextInt(colourSchemes.size());
        // System.out.println("chosen colourscheme "+i);
        if (rng.nextInt()==0)
            return colourSchemes.get(i);
        else
            return new ColourScheme(colourSchemes.get(i).background,colourSchemes.get(i).foreground);
    }

    static class ColourScheme {

        public Color background;
        public Color foreground;

        public ColourScheme(Color f, Color b) {
            foreground = f;
            background = b;
        }

    }

    static class TagDisplay {

        public WordCount wc;
        public Rectangle2D.Double rect;  // (x,y) gives top-left corner in
                                         // x -> y ^ coordinates,
                                         // (width,height) as given
        public int fontSize;

        public TagDisplay(WordCount wc) {
            this.wc = wc;
            rect = null;
            fontSize = 14; //default, will get overwritten
        }

    }

}