
/** A small container class that provides storage for a
  * word along with a integer counter.
  * This class implements the Comparable interface, which
  * allows lists of WordCount objects to be compared
  * (this is used when the cloud image is generated, to put
  * words with a higher count nearer the centre of the cloud).
  *
  * @author Sharon Curtis
  */
public class WordCount implements Comparable {

/** The word that is being counted. */
    public String word;

/** The variable remembering the count for this word */
    public int count;

/** Constructs a fresh WordCount object, and sets the count to 0.
  *
  * @param word           the word that will be counted
  * @param count          the count corresponding to the given word
  */
    public WordCount(String word, int count) {
        this.word = word;
        this.count = count;
    }

/** Compares this WordCount object to another WordCount object.
  * This enables lists of WordCount objects to be sorted.
  *
  * @pre         obj is of type WordCount
  * @param obj   the WordCount object to compare this WordCount to
  * @return      1 if this count is less than obj's count,
  *              -1 if vice versa, and 0 if they are equal
  */
    public int compareTo(Object obj) {
		WordCount wc = (WordCount)obj;
		if (this.count==wc.count)
		    return 0;
		else if (this.count<wc.count)
		    return 1;
		else
		    return -1;
	}

}