
import java.util.*;
import java.io.*;
import javax.swing.*;
import javax.swing.filechooser.*;

/** Makes a tag cloud from the words in a given file.
  *
  * @author Sharon Curtis
  */
public class TagCloud {

    // The default filename of the file containing the words for the tag cloud:
    private static String wordsFilename = "";
    // For speedy loading, change the above to the correct path & filename,
    // e.g.   "H:\\U08223\\hashmaps\\words.txt"
    // (The "\\"s represent a single backslash, as '\' is a special char in Java.)

    // The default filename of the file containing the common words:
    private static String commonWordsFilename = "";
    // Similarly, to automatically load a words file, change the above to
    // the correct path & filename of the file with the common words in.


    // The dialogue box for choosing files from:
    private static JFileChooser fc = new JFileChooser(".");
    private static WordStore words;

    public static void main(String[] args) {

        words = new WordStore();

        

        // now to load the words from the file
         loadCommonWords();
         loadWords();

        // now to get a list of the words along with their counts
         ArrayList<WordCount> tagCounts = words.getCounts();

        // now to show a pop-up window displaying the tag cloud
        // with all words that occur at least twice (parameter is 2)
         CloudMaker.showCloud(tagCounts,2);


        // keep the following line as the last line of the main method
        System.exit(0); // <- exits the program immediately
        // (the above line is handy if there's an invisible pop-up window
        // still hanging about preventing the program from terminating)
    }




    private static void loadWords() {
    // gets the words from the file containing the common words,
    // and puts them into the store of words containing strings

        File f = getFile(wordsFilename,
                         "Select the file containing words for the tag cloud");

        try {
            BufferedReader fileReader = new BufferedReader(new FileReader(f));
            String line = "";
            int count = 0;
            System.out.println("Reading the following words:");
            while ((line = fileReader.readLine()) != null) {

                // now to split the line up into separate words
                // using a StringTokenizer object
                StringTokenizer st = new StringTokenizer(line,
                                                         " ,./|?!()[]{};:<>*^\\\"\t\n\r\f");
                while (st.hasMoreTokens()) {
                    String nextWord = st.nextToken();
                    System.out.print(nextWord+" ");
                    words.addWord(nextWord.toLowerCase());
                    count++;
		    // putting in occasional printlns, to make it more readable
                    if (count%11==10)
                        System.out.println();
                }
            }
            fileReader.close();
            System.out.println("\n");

        }
        catch (Exception e) {
            System.out.println("An exception occurred when reading the file of words:\n"
                               + e.toString());
            e.printStackTrace();
        }
    }





    private static void loadCommonWords() {
    // gets the words from the file containing the common words,
    // and puts them into the word store

        File f = getFile(commonWordsFilename,
                         "Select the file containing the common words");
        try {
            BufferedReader fileReader = new BufferedReader(new FileReader(f));
            System.out.println("Noting the following common words:");
            String line = "";
            int count = 0;
            while ((line = fileReader.readLine()) != null) {
                // now to split the line up into separate words
                // using a StringTokenizer object
                StringTokenizer st = new StringTokenizer(line, " ,./|?!()[]{};:<>*^\\\"\t\n\r\f");
                while (st.hasMoreTokens()) {
                    String nextWord = st.nextToken();
                    words.addCommonWord(nextWord.toLowerCase());
                    count++;
                    System.out.print(nextWord+" ");
                    if (count%11==10)
                        System.out.println();
                }
            }
            System.out.println("\n");
            fileReader.close();

        }
        catch (Exception e) {
            System.out.println("An exception occurred when reading the file of common words:\n" + e.toString());
            e.printStackTrace();
        }
    }



    private static File getFile(String filename, String title) {
    // gets a File object that the user selects

        fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fc.setDialogTitle(title);

        // first try using the given filename, see if that works
        File f = new File(filename);
        while (!(f.exists() && f.isFile())) {
            if (filename.length()>0) { // if there was filename attempted,
                //  we need to display an alert box saying the file doesn't exist
                JOptionPane.showMessageDialog(null,
                                     "Sorry, the file \""+ filename + "\" does not exist.",
                                     "File does not exist",
                                     JOptionPane.WARNING_MESSAGE);
		    }

            int returnVal = fc.showOpenDialog(null);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                f = fc.getSelectedFile();
                fc.setCurrentDirectory(f.getParentFile());
            }
            else {
                System.out.println("No file selected. Program terminating.");
                System.exit(0);
			}
        }
        return f;
    }

}