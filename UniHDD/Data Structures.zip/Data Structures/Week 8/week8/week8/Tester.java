/** A class for testing a binary search method.
  *
  * @author David Lightfoot, Ian Bayley, Sharon Curtis (initially)
  */
public class Tester {


/** Carries out tests on a binary search method in the AscendingSequences class.
  *
  * @param args   not used
  */
    public static void main(String[] args) {

       

        // First need to set up a sequence with some data:
        AscendingSequence as = new AscendingSequence(25);
        System.out.println("Adding some elements to the sequence:");
        int[] somexs = {7, 4, 6, 3, 20, -12, -5}; // -12, -5, 3, 4, 6, 7, 20,
        as.insertLots(somexs);
        System.out.println(as);

        // Now to a test with this particular sequence:
        System.out.println("Can the binary search find the middle element?");
        System.out.println("Result of search for 4: " + as.search(4)+"\n");

        

        // Now do some more tests of your own. Include at least six examples.
		// Remember that you can clear the sequence and insertLots to make a new sequence to test
		// You can search also for elements that have been deleted etc

        //Test 1    -   test for lowest value
        System.out.println("Can the binary search find the lowest element?");
        System.out.println("Result of search for -12: " + as.search(-12)+"\n");
        

        //Test 2    -   test for highest value
        System.out.println("Can the binary search find the highest element?");
        System.out.println("Result of search for 20: " + as.search(20)+"\n");

         //Test 3    -   Search for a value that doesn't exist
        System.out.println("Can the binary search find an element that doesn't exist?");
        System.out.println("Result of search for 99 : " + as.search(99)+"\n");

        //Test 4    -   delete an item and search for it
        System.out.println("Will the binary search find an element that has been deleted?");
        System.out.println("Deleting the number 6...");
        as.remove(4);
        System.out.println(as);
        System.out.println("Result of search for 6 which should have been deleted: " + as.search(6)+"\n");

        //Test 5    -   test for a value in an array of 2
        as.clear();
        int[] secondArray = {2,4};
        as.insertLots(secondArray);
        System.out.println("Can the binary search find an element that exists in a 2 element sequence?");
        System.out.println(as);
        System.out.println("Result of search for 4 in a sequence of 2: " + as.search(4)+"\n");


        //Test 6    -   test for a value in an array of 1
        as.clear();
        as.insert(23);
        System.out.println("Can the binary search find an element that exists in a single element sequence?");
        System.out.println(as);
        System.out.println("Result of search for 23 in a sequence of 1: " + as.search(23)+"\n");

    /**
    Terminal window with ORIGNAL software
    Adding some elements to the sequence:
    [-12, -5, 3, 4, 6, 7, 20]
    Can the binary search find the middle element?
    Result of search for 4: true

    Can the binary search find the lowest element?
    Result of search for -12: false

    Can the binary search find the highest element?
    Result of search for 20: false

    Can the binary search find an element that doesn't exist?
    Result of search for 99 : false

    Will the binary search find an element that has been deleted?
    Deleting the number 6...
    [-12, -5, 3, 4, 7, 20]
    Result of search for 6 which should have been deleted: false

    Can the binary search find an element that exists in a 2 element sequence?
    [2, 4]
    Result of search for 4 in a sequence of 2: false

    Can the binary search find an element that exists in a single element sequence?
    [23]
    Result of search for 23 in a sequence of 1: false
     */


    /*
    Terminal window AFTER fix has been applied to search()
    Adding some elements to the sequence:
    [-12, -5, 3, 4, 6, 7, 20]
    Can the binary search find the middle element?
    Result of search for 4: true

    Can the binary search find the lowest element?
    Result of search for -12: true

    Can the binary search find the highest element?
    Result of search for 20: true

    Can the binary search find an element that doesn't exist?
    Result of search for 99 : false

    Will the binary search find an element that has been deleted?
    Deleting the number 6...
    [-12, -5, 3, 4, 7, 20]
    Result of search for 6 which should have been deleted: false

    Can the binary search find an element that exists in a 2 element sequence?
    [2, 4]
    Result of search for 4 in a sequence of 2: true

    Can the binary search find an element that exists in a single element sequence?
    [23]
    Result of search for 23 in a sequence of 1: true
    */
       


    }
}