
import javax.swing.*;
import java.awt.image.*;
import java.util.*;

public class TreePlay {

    public static void main(String[] args) {
int[] test = new int[5];

System.out.println(test.length);

       // creates a binary tree with some random numbers in it
       BinaryTree t = TreeUtilities.createRandomTree();


       // shows a pop-up window displaying tree t
       TreeUtilities.showTree(t);

       System.out.println("Pre-order :"+ t.preOrderTraversal());
       System.out.println("Post-order :"+t.postOrderTraversal());
       System.out.println("In-order :"+t.inOrderTraversal());
       System.out.println("Number of node : " + t.leafCount());
       System.out.println("Tree Height :" + t.height());





       // keep the following line as the last line of the main method
       System.exit(0); // <- exits the program immediately
       // (the above line is handy if there's an invisible pop-up window
       // still hanging about preventing the program from terminating)

    }
}