


/** Represents a simple binary tree of integers.
  *
  */
public class BinaryTree {

/** The integer stored at this tree node. */
    public int data;

/** A reference to this node's left subtree. */
    public BinaryTree left;

/** A reference to this node's right subtree. */
    public BinaryTree right;

/** Constructs a binary tree with a single node, using the given value.
  * Note that there is no constructor to construct an empty tree;
  * an empty tree is just represented by a null pointer.
  *
  * @param val     the integer value to be placed at the root node of this tree
  */
    public BinaryTree(int val) {
        data = val;
        left = null;
        right = null;
    }

    // your methods go here.....
public String inOrderTraversal() {
    String s = "";
    if (left != null){
        s = s + left.inOrderTraversal();
    }

        s = s + data + " ";

    if (right != null){
        s = s + right.inOrderTraversal();
    }
        return s;
}

public String postOrderTraversal() {
    String s = "";
    if (left != null){
        s = s + left.postOrderTraversal();
    }
    if (right != null){
        s = s + right.postOrderTraversal();
    }
    s = s + data + " ";
    return s;
}

public String preOrderTraversal() {
    String s = data + " "; // pre, because we get this node’s data first
    if (left != null){ // can’t apply a method to a non-existent object
        s = s + left.preOrderTraversal();
    }
    if (right != null){ // can’t apply a method to a non-existent object
        s = s + right.preOrderTraversal();
    }
    return s;
}

public int leafCount(){
    int count = 1;

    if (left != null){
        count = count + left.leafCount();
    }

    if (right != null){
        count = count + right.leafCount();
    }
    return count;
}

public int height(){
    int leftCount = 1,rightCount = 1;

    if (left != null){
        leftCount = leftCount + left.height();
    }

    if (right != null){
        rightCount = rightCount + right.height();
    }

    if (leftCount > rightCount){
        return leftCount;
    }else{
        return rightCount;
    }
}










// These are additional attributes that are used when working out how to
// draw the tree. You should ignore this code but leave it here.

    public int x,y;     // display position of this tree node

    public int boxWidth;      // used for calculating x,y coordinates
    public int nodeFromLeft;  // used for calculating x,y coordinates

    public int xdfp;          // x-distance of this node from parent node
    public int height;        // to calculate the height/depth of the tree


}
