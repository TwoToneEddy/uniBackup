/**
 *
 * @author David Lightfoot 2010-11-15; revised ...
 */
public class Sequence {

    private static long stepCount = 0;

    public static void clearNumSteps() {
        stepCount = 0;
    }

    public static long getNumSteps() {
        return stepCount;
    }
    public final int max;
    public int[] a;

    public Sequence(int max) {
        a = new int[max];
        this.max = max;
    }

    // pre 0 <= i && i < max
    // a[i] == x
    public void insertAt(int i, int x) {
        a[i] = x;
    }

    public String toString() {
        String out = "";
        for (int elem : a) {
            out += elem + "\n";
        }
        return out;
    }

    public boolean isAscending() {
        int i = 1;
        while (i < max && a[i - 1] <= a[i]) {
            i++;
        }
        return i >= max;
    }

    // pre true
    // post a[0..size-1] is ascending
    void insertionSort() {
        int i = 1;
        int x;
        int j;
        while (i < a.length) {
            // a[0..i-1] is ascending
            // insert value at a[i] into correct position in a[0..i-1]
            j = i;
            x = a[i]; // x is the value originally at a[i]
            stepCount ++; // Accessing each value in order of the array
            while (j != 0 && a[j - 1] > x) {
                stepCount++; // we have checked a[j-1]

                // 'budge up' values that are bigger than the one at a[i]
                a[j] = a[j - 1];
                stepCount ++; // Moving values in the array greater than x
                stepCount ++;
                j--;
            }  // j == 0 OR a[j-1] <= x
            // 'drop in' x, the value that was at a[j]
            if(j!=0){
                stepCount++; // counts if the while statment is false but we have
                            // still accessed a[j-1]
            }

            a[j] = x;
            stepCount ++; // Putting X in the correct part of the array
            i++; // advance to insert next value
        } // i >= a.length
    } // end of insertionSort

    void qSort(int low, int high) {
        int i = low, j = high, temp;
        int pivot = a[(low + high) / 2];

        while (i < j) {
            while (a[i] < pivot) {
                i++;
                stepCount++; // Checks if the value [i] in the lower part of the
            }                //sequence needs to be moved the other side of the pivot
            while (a[j] > pivot) {
                j--;
                stepCount++;// Checks if the value [i] in the upper part of the
            }                //sequence needs to be moved the other side of the pivot
            
            if (i <= j) {
                temp = a[i];
                stepCount++; // stores a[1]
                a[i] = a[j];
                stepCount++; // swaps 2 values
                stepCount++;
                a[j] = temp;
                i++;
                j--;
                stepCount++; // Actually moves the value
            }
        }
        if (low < j) {
            qSort(low, j); // recursive call
        }
        if (i < high) {
            qSort(i, high); // recursive call
        }
    } // end of insertionSort

    // pre true
    // post a[0..size-1] is ascending
    void quickSort() {
        qSort(0, max - 1);
    } // end of QSort
}
