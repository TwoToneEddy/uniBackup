

import java.util.*; // for random numbers
/**
 *
 * @author David Lightfoot 2010-11-15; revised, your name here
 */
public class SortExplore {

    public static void main(String[] args) {

        int numElements = 100; // edit this to change number of elements in array

        Random generator = new Random();
        Sequence s = new Sequence(numElements);
        Sequence oldS = new Sequence(numElements); // will hold original sequence

        for (int i = 0; i < numElements; i++) {
            s.insertAt(i, generator.nextInt());
        }

        for (int i = 0; i < numElements; i++) { // make oldS a copy of s
            oldS.a[i] = s.a[i];
        }



        System.out.println("Before sorting by Insertion Sort");
        System.out.println("sequence is ascending?:  " + s.isAscending());
        // System.out.println(s);
        Sequence.clearNumSteps();
        System.out.println("STARTING Insertion Sort");
        s.insertionSort();
        System.out.println("Insertion Sort done");

        System.out.println("After sorting by Insertion Sort ");
        System.out.println("sequence is ascending?:  " + s.isAscending());
        System.out.println("Number of steps is: " + Sequence.getNumSteps());
        //  System.out.println(s);
        System.out.println("\n");


        Sequence.clearNumSteps();
        //System.out.println("Restoring unsorted sequence ");
       // for (int i = 0; i < numElements; i++) { // restoring original s
        //    s.a[i] = oldS.a[i];
       // }
        System.out.println("STARTING QuickSort");
        s.quickSort();
        System.out.println("QuickSort done");

        System.out.println("After sorting by QuickSort ");
        System.out.println("sequence is ascending?:  " + s.isAscending());
        System.out.println("Number of steps is: " + Sequence.getNumSteps());
        System.out.println("\n");
        //Secondary sorting

        System.out.println("Before sorting for the 2nd time by Insertion Sort");
        System.out.println("sequence is ascending?:  " + s.isAscending());
        // System.out.println(s);
        Sequence.clearNumSteps();
        System.out.println("STARTING Insertion Sort number 2");
        s.insertionSort();
        System.out.println("Insertion Sort number 2 done");

        System.out.println("After sorting by Insertion Sort for the 2nd time ");
        System.out.println("sequence is ascending?:  " + s.isAscending());
        System.out.println("Number of steps is: " + Sequence.getNumSteps());
        //  System.out.println(s);
        System.out.println("\n");

        Sequence.clearNumSteps();
        //System.out.println("Restoring unsorted sequence ");
       // for (int i = 0; i < numElements; i++) { // restoring original s
       //     s.a[i] = oldS.a[i];
       // }
        System.out.println("STARTING QuickSort number 2");
        s.quickSort();
        System.out.println("QuickSort done");

        System.out.println("After sorting by QuickSort ");
        System.out.println("sequence is ascending?:  " + s.isAscending());
        System.out.println("Number of steps is: " + Sequence.getNumSteps());
    }
}
/*
 * Before sorting by Insertion Sort
sequence is ascending?:  false
STARTING Insertion Sort
Insertion Sort done
After sorting by Insertion Sort
sequence is ascending?:  true
Number of steps is: 7485


STARTING QuickSort
QuickSort done
After sorting by QuickSort
sequence is ascending?:  true
Number of steps is: 732


Before sorting for the 2nd time by Insertion Sort
sequence is ascending?:  true
STARTING Insertion Sort number 2
Insertion Sort number 2 done
After sorting by Insertion Sort for the 2nd time
sequence is ascending?:  true
Number of steps is: 297


STARTING QuickSort number 2
QuickSort done
After sorting by QuickSort
sequence is ascending?:  true
Number of steps is: 732

As you can see from above, the number of cycles for a quick sort is always the same
no matter the order of the sequence. The number of cycles for an insertion sort depends
on how well sorted the sequence is in the first place, if its already sorted it will
only check its sorted and not execute all of the code.

 */