/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package warm_up;

import java.util.*;
/**
 *
 * @author 09092543
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        ArrayList<Integer> list = new ArrayList<Integer>();

        for (int i =1; i<10;i=i+2){
            list.add(i);
        }
        list.remove(3);                         //This removes element 3 which is the
                                                //4th element in the array (7)
        System.out.println(list.toString());    //This prints the whole list
        
        for (int i: list){
            System.out.println(i);
        }
    }

}
