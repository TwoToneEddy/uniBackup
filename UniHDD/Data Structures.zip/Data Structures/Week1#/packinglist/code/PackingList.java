/**
 * Packing List (Java application version)
 * Author: Sharon Curtis
 * Date: 28th September 2010
 *
 * You do NOT need to read the code in this file
 * nor do you need to know how it works.
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

import java.util.*;

public class PackingList extends JFrame implements ActionListener {

	 public static void main(String args[]) {
	     // sets up an instance of this class
	     PackingList plApp = new PackingList();
 	 }

    public PackingList() {
        setDefaultLookAndFeelDecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(340,640);
        dataSetUp();
        setUpGUI();
        setVisible(true);
        askQuestions();
    }

// ------------------- GUI set up ---------------//

    ImageIcon minilogo, packIcon, unpackIcon, upIcon, downIcon;
    JLabel subheading, blank;
    JButton addOption, removeCancelOption, sortOption;
    JButton upButton, downButton, listButton;
    JPanel headerPanel, titlePanel, subtitlePanel, menuPanel;
    JPanel mainPanel, listPanel, addPanel;
    JScrollPane scrollPane;
    JTextField addBox;
    Color aqua = new Color(126,226,255);
    Color orange = new Color(255,150,0);

    public void setUpGUI() {

        // set up the title and logo
        headerPanel = new JPanel(new GridLayout(2,1));
        headerPanel.setBackground(Color.black);
        titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(Color.black);
        minilogo = new ImageIcon("images/bag.png");
        titlePanel.add(new JLabel(minilogo),BorderLayout.WEST);
        JLabel heading = new JLabel("Packing List",SwingConstants.CENTER);
        heading.setFont(new Font("Verdana", 0, 24));
        heading.setForeground(Color.white);
        heading.setBorder(new LineBorder(Color.black, 14));
        titlePanel.add(heading,BorderLayout.CENTER);
        headerPanel.add(titlePanel);

        // set up the sub-heading area
        subtitlePanel = new JPanel(new BorderLayout());
        subtitlePanel.setBackground(Color.black);
        subheading = new JLabel(" Items to Pack");
        subheading.setForeground(Color.white);
        subheading.setFont(new Font("Verdana", 0, 18));
        subtitlePanel.add(subheading, BorderLayout.CENTER);
        listButton = new JButton("View Packed");
        listButton.setActionCommand("swaplists");
        listButton.addActionListener(this);


        JPanel wrapperPanel = new JPanel(new FlowLayout());
        wrapperPanel.add(listButton);
        wrapperPanel.setBackground(Color.black);
        subtitlePanel.add(wrapperPanel, BorderLayout.EAST);
        headerPanel.add(subtitlePanel);
        getContentPane().add(headerPanel, BorderLayout.NORTH);


        packIcon = new ImageIcon("images/pack.png");
        unpackIcon = new ImageIcon("images/unpack.png");

        // set up the area with an add box
        addPanel = new JPanel(new GridLayout(1,1));
        addBox = new JTextField();
        addBox.setActionCommand("additem");
        addPanel.setBackground(Color.black);
        addBox.setFont(new Font("Verdana", 0, 16));
        blank = new JLabel(" ");
        blank.setBackground(Color.black);
        addPanel.add(blank);

        // set up the area with up/down buttons
        upIcon = new ImageIcon("images/up.png");
        downIcon = new ImageIcon("images/down.png");
        JPanel arrowPanel = new JPanel(new FlowLayout());
        arrowPanel.setBackground(Color.black);
        upButton = new JButton(upIcon);
        upButton.setBorder(new LineBorder(Color.black, 2));
        upButton.setBackground(Color.black);
        upButton.setActionCommand("up");
        upButton.addActionListener(this);
        arrowPanel.add(upButton);
        downButton = new JButton(downIcon);
        downButton.setBorder(new LineBorder(Color.black, 2));
        downButton.setBackground(Color.black);
        downButton.setActionCommand("down");
        downButton.addActionListener(this);
        arrowPanel.add(downButton);

                // set up the panel of menu "buttons" at the bottom
        menuPanel = new JPanel(new GridLayout(1,3));
        menuPanel.setBackground(new Color(239,239,239));

        addOption = new JButton(new ImageIcon("images/add.png"));
        //addOption = new JButton("Add");
        addOption.setBorder(new LineBorder(new Color(180,180,180), 2));
        addOption.setBackground(new Color(239,239,239));
        addOption.setActionCommand("add");
        addOption.addActionListener(this);
        menuPanel.add(addOption);
        removeCancelOption = new JButton(new ImageIcon("images/remove.png"));
        removeCancelOption.setBorder(new LineBorder(new Color(180,180,180), 2));
        removeCancelOption.setBackground(new Color(239,239,239));
        removeCancelOption.setActionCommand("removecancel");
        removeCancelOption.addActionListener(this);
        menuPanel.add(removeCancelOption);
        sortOption = new JButton(new ImageIcon("images/tidy.png"));
        sortOption.setBorder(new LineBorder(new Color(180,180,180), 2));
        sortOption.setBackground(new Color(239,239,239));
        sortOption.setActionCommand("sort");
        sortOption.addActionListener(this);
        menuPanel.add(sortOption);
        getContentPane().add(menuPanel, java.awt.BorderLayout.SOUTH);

        // set up the main area
        mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(addPanel,BorderLayout.NORTH);
        mainPanel.add(arrowPanel,BorderLayout.SOUTH);
        updateListView();
        scrollPane = new JScrollPane(listPanel);
        mainPanel.add(scrollPane,BorderLayout.CENTER);
        getContentPane().add(mainPanel, java.awt.BorderLayout.CENTER);

    }

    public void updateListView() {

        int cells;
        if (showingToPack && toPackItems!=null)
            cells = toPackItems.size();
        else if (!showingToPack && packedItems!=null)
            cells = packedItems.size();
        else
            cells = 0;
        if (cells>10)
            listPanel = new JPanel(new GridLayout(cells,1));
        else
            listPanel = new JPanel(new GridLayout(10,1));

        for (int i=0; i<cells; i++) {
            JPanel cellPanel = new JPanel(new BorderLayout());
            if (i==positionSelected)
                cellPanel.setBackground(orange);
            else
                cellPanel.setBackground(aqua);
            cellPanel.setBorder(new MatteBorder(2,0,2,0,new Color(0,121,178)));
            JButton clickIcon;
            if (showingToPack)
                clickIcon = new JButton(packIcon);
            else
                clickIcon = new JButton(unpackIcon);
            if (i==positionSelected)
                clickIcon.setBackground(orange);
            else
                clickIcon.setBackground(aqua);
            clickIcon.setBorder(BorderFactory.createEmptyBorder());
            clickIcon.setActionCommand("click"+i);
            clickIcon.addActionListener(this);
            cellPanel.add(clickIcon,BorderLayout.EAST);
            JLabel item;
            if (showingToPack)
               item = new JLabel("  "+toPackItems.get(i));
            else
               item = new JLabel("  "+packedItems.get(i));
            // System.out.println("setting a label for position "+i+": "+toPackItems.get(i));
            if (i==positionSelected)
                item.setBackground(orange);
            else
                item.setBackground(aqua);
            item.setFont(new Font("Verdana", 0, 14));
            item.setForeground(Color.black);
            cellPanel.add(item,BorderLayout.CENTER);
            listPanel.add(cellPanel);
        }
        for (int i=cells; i<10; i++) {
            JPanel cellPanel = new JPanel(new BorderLayout());
            cellPanel.setBackground(Color.black);
            JLabel placeholder = new JLabel(" ");
            placeholder.setFont(new Font("Verdana", 0, 14));
            cellPanel.add(placeholder);
            listPanel.add(cellPanel);
        }
    }

    public void askQuestions() {
        for (int i=0; i<qns.size(); i++) {
            // display the showOptionDialog
            int choice = JOptionPane.showOptionDialog(
               this,
               qns.get(i),
               "Question "+(i+1),
               JOptionPane.YES_NO_OPTION,
               JOptionPane.QUESTION_MESSAGE,
               null, null, null);

            // interpret the user's choice
            lists.conditionalAdd((choice == JOptionPane.YES_OPTION),
                                 additionalItems.get(i));
            redraw();
        }
    }

// --------------- setting up connections to the lists manager ---------------//

    ListsManager lists; // the connection to the lists manager
	boolean showingToPack=true; // to remember which list we're viewing
   	private boolean addingNew = false; // to remember if we're currently adding a new item
	int positionSelected = -1; // for remembering which element is selected currently
    ArrayList<String> toPackItems, packedItems; // references to the lists of items
                                                // held by the lists manager

    ArrayList<String> qns, additionalItems; // to store the questions that will
                                            // get asked when starting the app

    public void dataSetUp() {
        // initialising the data variables
        qns = new ArrayList<String>();
        additionalItems = new ArrayList<String>();

        toPackItems = new ArrayList<String>();
	packedItems = new ArrayList<String>();
        lists = new ListsManager(this);
	toPackItems = lists.itemsToPack;
	packedItems = lists.itemsPacked;
    }

    public void askQuestion(String text, String item) {
    // stores the information for the questions, to be asked later
        qns.add(text);
        additionalItems.add(item);
    }


// --------------- code for handling events ---------------//

    public void actionPerformed(ActionEvent e) {
        String which = e.getActionCommand();

        if (which.equals("swaplists")) {
            swapLists();
	    }
        else if (which.startsWith("click")) {
            moveItem(Integer.parseInt(which.substring(5)));
        }
        else if (which.equals("sort")) {
            sortList();
	    }
        else if (which.equals("add")) {
            startAdding();
        }
        else if (which.equals("additem")) {
            addItem();
        }
        else if (which.equals("removecancel")) {
            removeOrCancel();
        }
        else if (which.equals("up")) {
            moveUp();
        }
        else if (which.equals("down")) {
            moveDown();
        }

    }

    public void redraw() {
        updateListView();
        scrollPane.setViewportView(listPanel);
        repaint();
    }

    public void moveItem(int position) {
        positionSelected=-1;
        System.out.println("position is "+position);
		if (showingToPack)
           lists.pack(position);
        else
           lists.unpack(position);
        redraw();
    }

    public void moveUp() {
    // moves the selection highlight up by 1, wrapping
        int cells;
        if (showingToPack)
            cells = toPackItems.size();
        else
            cells = packedItems.size();

        positionSelected--;
        if (positionSelected<0)
            positionSelected = cells-1;
        redraw();
    }

    public void moveDown() {
    // moves the item selection highlight down by 1, wrapping
        int cells;
        if (showingToPack)
            cells = toPackItems.size();
        else
            cells = packedItems.size();
        positionSelected++;
        if (positionSelected>=cells)
            positionSelected = 0;
        redraw();
    }

    public void swapLists() {
        showingToPack = !showingToPack;
        if (showingToPack) {
            listButton.setText("View Packed");
            subheading.setText(" Items to Pack");
        }
        else {
            listButton.setText("View Unpacked");
            subheading.setText(" Items Packed");
        }
        redraw();
    }

    private void startAdding() {
    // readies the interface to be in an "adding new item" state
        addingNew = true;
        removeCancelOption.setIcon(new ImageIcon("images/cancel.png"));
        addPanel.remove(blank);
        addBox.setText("");
        addBox.addActionListener(this);
        addPanel.add(addBox);
        addBox.requestFocus();
        validate();
        repaint();
    }

    private void addItem() {
        String item = addBox.getText();
	if (showingToPack)
            lists.addItemToPack(item);
        else
            lists.addPackedItem(item);
        addBox.setText("");
        cancelAdd();
    }

    private void cancelAdd() {
    // cancels the adding of a new element that the user was in the middle of
	addingNew = false;
        removeCancelOption.setIcon(new ImageIcon("images/remove.png"));
        addPanel.remove(addBox);
        addBox.removeActionListener(this);
        addPanel.add(blank);
        redraw();
    }

    private void removeOrCancel() {
		if (addingNew)
           cancelAdd();
     	else if (positionSelected > -1)
		   removeItem(positionSelected);
    }

    private void removeItem(int index) {
		if (showingToPack)
			lists.removeItemToPack(index);
        else
			lists.removePackedItem(index);
        positionSelected = -1;
        redraw();
	}

    public void sortList() {
		if (showingToPack)
			lists.tidyUnpackedItems();
        else
			lists.tidyPackedItems();
        redraw();
    }

}
