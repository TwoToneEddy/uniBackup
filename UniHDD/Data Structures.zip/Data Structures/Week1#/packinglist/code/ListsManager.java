/*
 * Provides methods to manage the two packing lists.
 */

import java.util.*;

public class ListsManager {

    public ArrayList<String> itemsToPack, itemsPacked;
    public PackingList controller;

    public ListsManager(PackingList ref) {
        controller = ref;
        initialiseLists();
    }

/* Initialises both lists.
 */
    private void initialiseLists() {
    itemsToPack = new ArrayList<String>();
    itemsPacked = new ArrayList<String>();

    controller.askQuestion("Will you be wearing glasses?",
                       "Glasses case");
    controller.askQuestion("Will you need a coin for the locker?",
                       "Coin for the locker");


    itemsToPack.add("phone");
    itemsToPack.add("money");
    itemsToPack.add("wallet");
       // not implemented yet

    }


/* Adds the given item to the list of items to pack, but only
 * if required.
 */
    public void conditionalAdd(boolean okToAdd, String item) {

       // not implemented yet
        if(okToAdd == true){
            itemsPacked.add(item);
        }

    }

/* Adds the given item to the beginning of the list of items to pack.
 */
    public void addItemToPack(String item) {

       // not implemented yet
       itemsToPack.add(0, item);

    }

/* Adds the given item to the beginning of the list of items already packed.
 */
    public void addPackedItem(String item) {

       // not implemented yet
        itemsPacked.add(0, item);

    }

/* Removes the item at the given position from the list of items to pack.
 */
    public void removeItemToPack(int index) {

       // not implemented yet
        itemsToPack.remove(index);

    }

/* Removes the item at the given position from the list of items already packed.
 */
    public void removePackedItem(int index) {

       // not implemented yet
        itemsPacked.remove(index);

    }

/* Packs the item at the given position by removing from the list of unpacked
 * items and adding it to the list of already packed items.
 */
    public void pack(int index) {

       // not implemented yet
       // itemsPacked.add(itemsToPack.get(index));
        itemsPacked.add(itemsToPack.get(index));
        itemsToPack.remove(index);
        

    }

/* Unpacks the item at the given position by removing from the list of packed
 * items and adding it to the list of unpacked items.
 */
    public void unpack(int index) {

       // not implemented yet
       itemsToPack.add(itemsPacked.get(index));
       itemsPacked.remove(index);
    }


/* Tidies up the list of items already packed.
 */
    public void tidyUnpackedItems() {

       // not implemented yet
       Collections.sort(itemsToPack);
    }

/* Tidies up the list of items to pack.
 */
    public void tidyPackedItems() {

       // not implemented yet
        Collections.sort(itemsPacked);

    }

}
