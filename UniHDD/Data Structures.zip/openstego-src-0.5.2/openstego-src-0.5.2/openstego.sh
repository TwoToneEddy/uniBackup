java -Xmx512m -jar ./lib/openstego.jar $*
