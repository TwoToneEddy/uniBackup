/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dlfilesexample;

/**
 *
 * @author 09092543
 */
import java.io.*;

class DLFilesExample {

  public static FileInputStream openStream(String fileName)
    throws FileNotFoundException {
    FileInputStream fis = new FileInputStream(fileName);
    System.out.println("File input stream created");
    return fis;
  }

  public static void main(String args[]) {
    FileInputStream fileInputStream = null;
    
    //String fileName = "data.txt"; // 0
    // String fileName = "foo.bar"; // 1
     String fileName = null; // 2



    System.out.println("Starting with file name = " + fileName);

    // attempt to get file input stream 
    try {
      fileInputStream = openStream(fileName);
    }
    catch (FileNotFoundException ex){
      System.out.println("Whoops: FileNotFoundException caught: no such file");
    }
    catch(NullPointerException ex){
        System.out.println("Whoops: NullPointerException caught: filename is null!!");
    }
  }
}

