/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package stopwatch;
import java.awt.Container;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import javax.swing.Timer;



/**
 *
 * @author 09092543
 */
public class StopWatch implements ActionListener {

    /**
     * @param args the command line arguments
     */
    
    private JFrame frame = new JFrame("Digital Stopwatch");
    private JPanel buttonPanel = new JPanel();
    private JButton startButton = new JButton("Start");
    private JButton stopButton = new JButton("Stop");
    private JTextField timeField = new JTextField("");
    private long startTime;
    private Timer timer;

    
    public StopWatch() {
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        buttonPanel.add(startButton);
        buttonPanel.add(stopButton);
        stopButton.setEnabled(false);

        startButton.addActionListener(this);
        stopButton.addActionListener(this);

        Container contentPane = frame.getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
        timeField.setEditable(false);
        contentPane.add(timeField);
        contentPane.add(buttonPanel);

        timer = new Timer(100, this);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
    
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == startButton) {
                startTime = e.getWhen();
                timer.start();
                stopButton.setEnabled(true);
                startButton.setEnabled(false);
            }
            if (e.getSource() == timer) {
                setTimeField(e.getWhen());
            }
            if (e.getSource() == stopButton) {
                setTimeField(e.getWhen());
                timer.stop();
                stopButton.setEnabled(false);
                startButton.setEnabled(true);
            }
    }
        private void setTimeField(long time) {
        long elapsed = time - startTime;
        long centisecs = elapsed / 10;
        long seconds = centisecs / 100;
        long minutes = seconds / 60;
        long hours = minutes / 60;

        NumberFormat nf = NumberFormat.getNumberInstance();
        nf.setMinimumIntegerDigits(2);

        String timeStr = "" + nf.format(hours) + ":"
                + nf.format(minutes % 60) + ":"
                + nf.format(seconds % 60) + "."
                + nf.format(centisecs % 100);

        timeField.setText(timeStr);
    }



    public static void main(String[] args) {
        new StopWatch();
    }

}
