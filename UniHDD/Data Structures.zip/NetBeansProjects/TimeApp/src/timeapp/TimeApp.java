/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package timeapp;

/**
 *
 * 
 */
//@author 09092543
import java.awt.Container;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.util.Date;


public class TimeApp extends JFrame implements ActionListener  {

    JButton button = new JButton("Get Time");
    JLabel label = new JLabel("  Button last pressed at ..................");

    public static void main(String[] args) {
        new TimeApp();
    }

    public TimeApp() {
        super("Time");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        button.addActionListener(this);
        
        Container contentPane = getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
        contentPane.add(button);
        contentPane.add(label);

        pack();
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        DateFormat df = DateFormat.getTimeInstance();
        label.setText("  Button last pressed at " + df.format(new Date()));
    }

}

