/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practical2;

/**
 *
 * @author 09092543
 */
public class SimpleStats {

    private double sum, lastElement;
    private int count;

    public double getSum() {
        return sum;
    }

    public int getCount() {
        return count;
    }

    public double getAverage() {
        return getSum() / getCount();
    }

    public void add(double element) {
        lastElement = element;
        count++;
        sum += element;
    }

    public double getLastElement() {
        return lastElement;
    }
}

