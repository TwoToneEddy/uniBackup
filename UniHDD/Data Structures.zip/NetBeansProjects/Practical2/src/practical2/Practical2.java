/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practical2;
import java.util.Scanner;
/**
 *
 * @author 09092543
 */
public class Main {

    private static SimpleStats myStats = new SimpleStats();
    private static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        String option;
        do {
            System.out.println("Options are:");
            System.out.println("A: Add a value");
            System.out.println("P: Print out the statistics of the collection");
            System.out.print("Enter your option > ");
            option = scan.nextLine();

            if (option.equalsIgnoreCase("A")) {
                addValue(myStats);
            }

            if (option.equalsIgnoreCase("P")) {
                printStats(myStats);
            }
            System.out.println();

        } while (!option.equalsIgnoreCase("Q"));

    }

    private static void addValue(SimpleStats stats) {
        System.out.print("Enter value to be added > ");
        double d = scan.nextDouble();
        stats.add(d);
    }

    private static void printStats(SimpleStats stats) {
        System.out.println("Count = " + stats.getCount());
        System.out.println("Sum = " + stats.getSum());
        if (stats.getCount() > 0) {
            System.out.println("Average = " + stats.getAverage());
        }
    }
}

