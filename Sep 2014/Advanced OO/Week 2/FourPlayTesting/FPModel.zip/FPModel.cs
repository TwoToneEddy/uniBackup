
using System;

public delegate void UpdatedEventHandler(object sender, EventArgs e);

namespace modelTest
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			FPModel model = new FPModel ();

			if (model.winningLine (1) == true) {
				Console.WriteLine ("Winning line found");
			} else {
				Console.WriteLine ("Winning line NOT found");
			}

			Console.WriteLine ("setting pieces...");
			model.setPiece (0, 0, 1);
			model.setPiece (0, 1, 1);
			model.setPiece (0, 2, 1);
			model.setPiece (0, 3, 1);
			Console.WriteLine ("pieces set!");

			if (model.winningLine (1) == true) {
				Console.WriteLine ("Winning line found");
			} else {
				Console.WriteLine ("Winning line NOT found");
			}
				
			Console.ReadLine();
		}
	}

	public class FPModel
	{

		public event UpdatedEventHandler Updated;

		protected virtual void OnUpdated(EventArgs e)
		{

			if (Updated != null)
			{
				this.Updated(this, e);
			}
		}

		private static int noOfColomns = 7;
		private static int noOfRows = 6;
		private int[][] boardStatus = new int[noOfRows][];
		private int player1, player2;
		private bool boardEmpty = true;


		public FPModel()
		{
			player1 = 0;
			player2 = 0;

			//int[][] boardStatus = new int[noOfRows][];
			for (int x = 0; x < boardStatus.Length; x++) 
			{
				boardStatus[x] = new int[noOfColomns];
			}



			initialise();
		}

		public void initialise()
		{
			for (int i = 0; i < noOfRows; i++)
			{
				for (int j = 0; j < noOfColomns; j++)
				{
					boardStatus[i][j] = 0;
				}
			}
			boardEmpty = true;
			this.OnUpdated(new  EventArgs());
		}

		public int NoOfColomns
		{
			get{return noOfColomns;}
		}


		public int NoOfRows
		{
			get{ return noOfRows;}
		}


		public int[][] ChipStatus
		{
			get{ return boardStatus; }
		}


		public int getScore(int player)
		{
			switch (player)
			{
			case 1:
				return player1;
			case 2:
				return player2;
			default:
				return 0;
			}
		}


		public void setScore(int player, int score)
		{
			if (player == 1)
			{
				player1 = score;
			}
			if (player == 2)
			{
				player2 = score;
			}
			this.OnUpdated(new  EventArgs());
		}


		public void setPiece(int row, int colomn, int value)
		{
			if (boardEmpty == true)
			{
				boardEmpty = false;
			}
			boardStatus[row][colomn] = value;
			this.OnUpdated(new  EventArgs());
		}


		public bool boardIsEmpty()
		{
			return boardEmpty;
		}

		public bool winningLine(int player)
		{
			if (verticalWin(player) || horizontalWin(player) || upwardDiagonalWin(player) || downwardDiagonalWin(player))
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		private bool verticalWin(int player)
		{
			int counter = 0;
			for (int i = 0; i < noOfColomns; i++)
			{
				counter = 0;
				for (int j = 0; j < noOfRows; j++)
				{
					if (boardStatus[j][i] == player)
					{
						counter++;
						if (counter == 4)
						{
							return true;
						}
					}
					else
					{
						counter = 0;
					}
				}
			}
			return false;
		}

		private bool horizontalWin(int player)
		{
			int counter = 0;
			for (int i = 0; i < noOfRows; i++)
			{
				counter = 0;
				for (int j = 0; j < noOfColomns; j++)
				{
					if (boardStatus[i][j] == player)
					{
						counter++;
						if (counter == 4)
						{
							return true;
						}
					}
					else
					{
						counter = 0;
					}
				}
			}
			return false;
		}

		private bool upwardDiagonalWin(int player)
		{
			int counter = 0;
			for (int i = 0; i < noOfColomns - 3; i++)
			{
				for (int j = 0; j < noOfRows - 3; j++)
				{
					counter = 0;
					for (int k = 0; k < 4; k++)
					{
						if (boardStatus[j + k][i + k] == player)
						{
							counter++;
							if (counter == 4)
							{
								return true;
							}
						}
					}
				}
			}
			return false;
		}

		private bool downwardDiagonalWin(int player)
		{
			int counter = 0;
			for (int i = 0; i < noOfColomns - 3; i++)
			{
				for (int j = 3; j < noOfRows; j++)
				{
					counter = 0;
					for (int k = 0; k < 4; k++)
					{
						if (boardStatus[j - k][i + k] == player)
						{
							counter++;
							if (counter == 4)
							{
								return true;
							}
						}
					}
				}
			}
			return false;
		}

	}
}
