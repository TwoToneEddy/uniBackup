public interface ControllerInterface {
    void change();
    void initialise();
    AbstractTrafficLightView getView();
}
